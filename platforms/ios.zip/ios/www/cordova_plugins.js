cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "file": "plugins/com.ionic.keyboard/www/keyboard.js",
        "id": "com.ionic.keyboard.keyboard",
        "clobbers": [
            "cordova.plugins.Keyboard"
        ]
    },
    {
        "file": "plugins/org.apache.cordova.device/www/device.js",
        "id": "org.apache.cordova.device.device",
        "clobbers": [
            "device"
        ]
    },
    {
        "file": "plugins/com.google.cordova.admob/www/AdMob.js",
        "id": "com.google.cordova.admob.AdMob",
        "clobbers": [
            "window.AdMob"
        ]
    },
    {
        "file": "plugins/com.admob.google/www/admob.js",
        "id": "com.admob.google.AdMobAds",
        "clobbers": [
            "window.admob",
            "window.tappx"
        ]
    },
    {
        "file": "plugins/com.ionic.deploy/www/ionicdeploy.js",
        "id": "com.ionic.deploy.IonicDeploy",
        "clobbers": [
            "IonicDeploy"
        ]
    },
    {
        "file": "plugins/com.connectivity.monitor/www/connectivity.js",
        "id": "com.connectivity.monitor.connectivity",
        "clobbers": [
            "window.connectivity"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "com.ionic.keyboard": "1.0.4",
    "org.apache.cordova.device": "0.3.0",
    "com.google.cordova.admob": "2.7.4",
    "com.admob.google": "2.0.13",
    "com.ionic.deploy": "0.1.0",
    "com.rjfun.cordova.extension": "1.0.6",
    "com.connectivity.monitor": "1.1.0",
    "com.ios.libgoogleadmobads": "1.1.1"
}
// BOTTOM OF METADATA
});