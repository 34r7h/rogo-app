//
//  AdMobMediation.m
//  TestAdMobCombo
//
//  Created by Xie Liming on 14-10-29.
//
//

#import "AdMobMediation.h"

@implementation AdMobMediation

- (AdMobMediation*) initWithOptions:(NSDictionary*)options {
    return self;
}

- (void) joinAdRequest:(GADRequest*)req {
    
}

- (void) onPause {
    
}

- (void) onResume {
    
}

- (void) onDestroy {
    
}

@end

